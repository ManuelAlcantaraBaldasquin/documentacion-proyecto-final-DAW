<?php
include ('actions/dbConfig.php');
  	$sql  = "SELECT * FROM `diccionario` ORDER BY `IDuser`;";
  	$reg = $mysqli->query($sql);

?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>diccionarioAdmin</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    	<link rel="stylesheet" href="../css/style.css">
    	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
		<script type="text/javascript" src="js/scripts.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
		
	</head>
	<body>
	<div class="header">
		<a href="main.php?destroy" class=" logout fas fa-sign-out-alt ">Desconectarse</a>
		<p class="logo">Listado completo de diccionarios</p>
		<a href="usuarios.php" class="">Ver usuarios</a>
		<a href="diccionarioAdmin.php" class="">Ver diccionarios</a>

  </div>
	<br>
	
	

 	 <div class="col-xs-8 col-md-12 centerTable"> 
    <table class="table" id="tDiccionario">
      <tr>
        <th>ID del usuario</th><th>Nombre</th><th>Descripción</th><th>Idioma</th><th colspan="2">Acciones</th>
      </tr>
      <tr>
       <!-- Bucle por cada registro muestra en la tabla (IDuser, nombre, descripcion y idioma) -->
        <?php while ($row = mysqli_fetch_assoc($reg)) {?>
				<td class=""> <?php echo $row["IDuser"]; ?> </td>
        <td class=""> <?php echo $row["nombre"]; ?> </td>
        <td class=""> <?php echo $row["descripcion"]; ?> </td>
		<td class=""> <?php echo $row["idioma"]; ?> </td>
		<td><button id="openDeleteDic" onclick="eliminarDiccionario(<?=$row["IDdiccionario"]?>)" data-backdrop="false" type="submit" class="btn btn-danger" data-toggle="modal"
			data-target="#deleteModal">
				<i class="fas fa-trash-alt"></i> Eliminar</button>
		</td>
		<td>
				<button id="abrirPalabras" onclick="buscarPalabras(<?=$row["IDdiccionario"]?>)" type="button" class="btn btn-primary" data-backdrop="false" data-toggle="modal"
				data-target="#palabrasModal">
				<i class="fas fa-external-link-alt"></i> Abrir</button>
		</td>
      </tr>
      <?php }; ?>
    </table></div>
    
<!-- Palabras Modal		   -->
  <div class="modal fade" id="palabrasModal" role="dialog">   
	</div> 

<!-- Delete Modal -->
  <div class="modal fade" id="deleteModal" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<form name="delete_diccionario" id="delete_diccionario" method="post">
					<div class="modal-header">						
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title">Eliminar Diccionario</h4>
					</div>
					<div class="modal-body">					
						<p>¿Seguro que quiere eliminar el diccionario?</p>
						<p class="text-warning"><small>Esta acción no se puede deshacer</small></p>
						<input type="hidden" name="delete_id" id="delete_id">
					</div>
					<div class="modal-footer">
          			<button onclick="confirmDeleteDicc()" type="submit" class="btn btn-danger" data-dismiss="modal">Eliminar</button>
          			<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
					</div>
				</form>
			</div>
		</div>
	</div>
	

	</body>
</html>
