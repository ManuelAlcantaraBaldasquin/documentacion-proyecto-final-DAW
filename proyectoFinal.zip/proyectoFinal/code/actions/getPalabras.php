<?php
if (isset($_POST['otro'])) {
    if ($_POST['otro'] == 'nueva_palabra'){
?>
	<tr id="nueva_palabra">
		<td><input class="palabra" type="text"></input></td>
		<td><input class="significado" type="text"></td>
		<td><input class="ejemplo" type="text"></td>
		<td><button onclick="guardar_nueva_palabra()" class="btn">
		<i class="fas fa-trash-alt"></i> Guardar</button></td>
	</tr>



<?php    
    }
    if ($_POST['otro'] == 'ultima_palabra')
    {
        include('DBconfig.php');
        $IDdiccionario = $_POST["id"];
        $sql = "SELECT * FROM palabras WHERE IDdiccionario = '$IDdiccionario' ORDER BY IDdiccionario DESC LIMIT 1";
        $reg = $mysqli->query($sql);
        $row = mysqli_fetch_assoc($reg);
        ?>
        <tr>         
        <td class=""> <?php echo $row["palabra"]; ?> </td>
        <td class=""> <?php echo $row["significado"]; ?> </td>
        <td class=""> <?php echo $row["ejemplo"]; ?> </td>
		<td><button id="openDeletePal" onclick="eliminarPalabra(<?=$row["IDpalabras"]?>)" type="submit" class="btn btn-danger">
			<i class="fas fa-trash-alt"></i> Eliminar</button>
		</td>
		</tr>
		<?php
    }
}
else{
   
    include ('dbConfig.php');
    session_start();

		$IDdiccionario = $_POST["id"]; 
  	
  $sql = "SELECT * FROM palabras WHERE IDdiccionario = '$IDdiccionario'";
  $reg = $mysqli->query($sql);
  
  	
?>
<div class="modal-dialog">
      <div class="modal-content" style="overflow-x:auto;">
<div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Lista Palabras</h4>
          <button onclick="crearPalabras()" id="openCreatePal" data-backdrop="false" style="float: right" type="button" class="btn btn-success" data-toggle="modal" data-target="#createPalabraModal">
	<i class="fas fa-plus-square"></i> crear palabra</button>
        </div>
        <div class="modal-body">
<div class="col-xs-6 col-md-12">

          <table style="width:100%" class="table" id="tDiccionario">
      <tr>
        <th style="width:12.5%">Palabra</th><th style="width:12.5%">Significado</th><th style="width:50%">Ejemplo</th><th style="width:25%" colspan="3">Acciones</th>
      </tr>
      <tr>
        <?php
        while ($row = mysqli_fetch_assoc($reg)) {?>
        <td class=""> <?php echo $row["palabra"]; ?> </td>
        <td class=""> <?php echo $row["significado"]; ?> </td>
        <td class=""> <?php echo $row["ejemplo"]; ?> </td>
				<td><button id="openDeletePal" onclick="eliminarPalabra(<?=$row["IDpalabras"]?>)" type="submit" class="btn btn-danger">
				<i class="fas fa-trash-alt"></i> Eliminar</button>
		</td>
				</tr>
      <?php }; ?>
    </table></div>
    
    </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        </div>
        
        </div>
    </div>
    <?php }; ?>