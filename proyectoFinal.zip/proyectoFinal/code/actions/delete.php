<?php
include "dbConfig.php";

$id = $_POST['id'];

mysqli_query($mysqli,"DELETE FROM diccionario WHERE IDdiccionario = $id");

?>
