<?php
//including the database connection file
include('DBconfig.php');
session_start();
    
    $IDuser = $_POST['IDuser'];
    $nombre = $_POST['nombre'];
    $idioma = $_POST['idioma'];
    $IDidioma = $_POST['IDidioma'];
    $descripcion = $_POST['descripcion'];
    
    mysqli_query($mysqli, "INSERT INTO diccionario(IDuser, nombre, idioma, IDidioma, descripcion) VALUES ('$IDuser', '$nombre', '$idioma', '$IDidioma', '$descripcion')");
?>