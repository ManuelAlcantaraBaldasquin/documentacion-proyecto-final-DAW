<?php
//including the database connection file
include('DBconfig.php');
session_start();
    
    $IDdiccionario = $_POST['IDdiccionario'];
    $nombre = $_POST['nombre'];
    $idioma = $_POST['idioma'];
    $IDidioma = $_POST['IDidioma'];
    $descripcion = $_POST['descripcion'];
    
    
    mysqli_query($mysqli, "UPDATE diccionario WHERE IDdiccionario = '$IDdiccionario' SET nombre='".$nombre."', idioma='".$idioma."', descripcion='".$descripcion."', IDidioma='".$IDidioma."' ");
    
?>