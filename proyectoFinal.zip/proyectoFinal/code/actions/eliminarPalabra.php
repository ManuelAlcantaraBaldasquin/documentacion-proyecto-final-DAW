<?php
include "dbConfig.php";

$id = $_POST['id'];

mysqli_query($mysqli,"DELETE FROM palabras WHERE IDpalabras = $id");

?>
