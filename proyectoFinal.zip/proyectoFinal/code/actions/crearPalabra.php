<?php
//including the database connection file
include('DBconfig.php');
session_start();
    
    $palabra = $_POST['palabra'];
    $significado = $_POST['significado'];
    $ejemplo = $_POST['ejemplo'];
    $IDdiccionario = $_POST['id'];
    
    mysqli_query($mysqli, "INSERT INTO palabras VALUES ('NULL', '$palabra', '$significado', '$ejemplo', '$IDdiccionario')");
?>