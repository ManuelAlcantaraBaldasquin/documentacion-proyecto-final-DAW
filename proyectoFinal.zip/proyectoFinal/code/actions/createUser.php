<?php
//including the database connection file
include('DBconfig.php');
session_start();
    
    $mail = $_POST['mail'];
    $user = $_POST['user'];
    $password = $_POST['password'];
    

//     $sql  = "SELECT * FROM usuarios where mail = $mail;";
//     $reg = $mysqli->query($sql);
//     if ($reg->rowCount()){
//         $msgUsuarioRegistrado = "Ya existe un usuario con ese mail";
//     }else{
    mysqli_query($mysqli, "INSERT INTO usuarios(mail, user, password) VALUES ('$mail', '$user', '$password')");
//     }
?>