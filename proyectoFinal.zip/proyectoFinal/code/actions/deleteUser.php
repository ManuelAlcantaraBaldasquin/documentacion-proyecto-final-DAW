<?php
include "dbConfig.php";

$id = $_POST['id'];

mysqli_query($mysqli,"DELETE FROM usuarios WHERE IDuser = $id");

?>
