<?php
include ('actions/dbConfig.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Register</title>

	<meta charset="utf-8">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript" src="js/scripts.js"></script>
	  
	  <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
<style>
</style>
</head>
<body class="full-viewport">
<div id="mainContent" style="width: 100%; height: 100%;">
<div class="backgroundRegister display-flex fullWidth justify-content-center align-items-center">
<div class="col-8 col-lg-4">
<div id="registerForm" class="containerLogin centerTable">
	<form name="crear_usuario" id="create_user" method="POST">
		<h1>Register</h1>
		<?= isset($msgUsuarioRegistrado) ? $msgUsuarioRegistrado : "" ; ?>
		
		<p><label><b>E-mail</b></label><br>
		<input class="form-control input-width" type="email" placeholder="Introduce email" name="mail" id="mail" required /><p>
		
		<p><label><b>Usuario</b></label><br>
		<input class="form-control input-width" type="text" placeholder="Introduce usuario" name="user" id="user" required /><p>

		<p><label><b>Contraseña</b></label><br>
		<input class="form-control input-width" type="password" placeholder="Introduce contraseña" name="password" id="password" required /><p>
		
		<p><button name="crearUsuarioButton" onclick="crearUsuario()" class="btn btn-success">Crear</button>
        <button type="reset" class="btn btn-danger">Cancelar</button></p>
        <a href="index.php"><i class="fas fa-home"></i>Volver al Inicio</a>
		
	</form>
	
	</div>
</div>
</div>
</div>
	
</body>
</html>


