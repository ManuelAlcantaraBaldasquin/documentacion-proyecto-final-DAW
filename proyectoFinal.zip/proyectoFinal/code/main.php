<?php
	//comprobar la sesión
	session_start();
	function destruir_session() {
		// Destruir variables de sesión
		$_SESSION[] = array() ;
		// Destruimos la sesión
		session_destroy() ;
		header("location:index.php") ;
	}
	// Si se nos indica, destruimos la sesión.
	if (isset($_GET["destroy"])) {
		destruir_session() ;
	}


?>
