<?php
 include_once '../api/api.php';
 include ('actions/dbConfig.php');

	//iniciar sesión
	session_start() ;
	if (isset($_POST["user"])) {

	//comprobar si hay errores al conectar
	if ($mysqli->connect_errno) {
			die("**Error $mysqli->connect_errno: $mysqli->connect_error.<br/>") ;
		}
	// Escapamos las cadenas correctamente para evitar inyección de código
		$user = $mysqli->real_escape_string($_POST["user"]) ;
		$password = $mysqli->real_escape_string($_POST["password"]) ;

	//Comprobar user
	$sql  = "SELECT * FROM usuarios WHERE user='$user' AND password='$password';" ;
	$reg = $mysqli->query($sql) ; //ejecuta la sentencia

	$datos = mysqli_fetch_assoc($reg); //guardamos los registros en un array
	if ($reg->num_rows) {
		$_SESSION["IDuser"] = $datos["IDuser"];
		$_SESSION["user"] = $_POST["user"] ;

	// Redirigimos
	if ($datos["admin"] == 1) {
			//usuario admin
			header("location:diccionarioAdmin.php");
		}else{
			//usuario corriente
			header("location:diccionario.php");
		}
		} else {
			$msg = "<p>Error al iniciar sesion</p>" ;
		}
		// Cerrar la conexión de la base datos.
		$mysqli->close() ;
	}
  //creamos la variable para que sea igual a la función
	$topIdioma = topIdioma();
	//esta variable almacena el json_decode
	$paraDecode = json_decode($topIdioma, true);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<meta charset="utf-8">
	
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
	
	<script type="text/javascript" src="js/scripts.js"></script>

</head>
<body class="full-viewport">
<div  id="mainContent" style="width: 100%; height: 100%;">
<div class="backgroundIndex display-flex justify-content-center align-items-center">
<div class="col-8 col-lg-4">
	
	<div class="encabezadoIndex">
	<h1>My Dictionary</h1>
	<?= isset($msg) ? $msg : "" ; ?>
	</div>
	
	<p><b style="color: white;">El idioma más popular en este momento es el <?=$paraDecode["idioma"]?></b><p>

	<div id="loginForm" class="containerLogin centerTable">
	<form  method="POST" >
		<h1>Login</h1>
		<p><label for="user"><b>Usuario</b></label>
		<input class="form-control input-width" type="text" placeholder="Introduce usuario" name="user" id="user" required /></p>

		<p><label for="password"><b>Contraseña</b></label>
		<input class="form-control input-width"  type="password" placeholder="Introduce contraseña" name="password" id="password" required /></p>

		<p><button type="submit" class="btn btn-success">Entrar</button>
        <button type="reset" onclick="mostrarLoginForm(1)" class="btn btn-danger">Cancelar</button></p>
        
        <p>¿Aún no tienes cuenta? <a href="register.php" class="fas fa-sign-in-alt"> Regístrate aquí</a>
	</form>
	</div>
	</div>
</div>
	
<div id="index2" class="backgroundIndex2 fullHeight fullWidth">
<div id="RightText" class="container-index-2 index-text-2">
<h4 style="color:white; text-align:center;">¿Qué es My Dictionary?</h4>

<p class="ex1">My Dictionary es una página que te permite crear tus propios diccionarios en el idioma
que necesites y apuntar en estos las palabras que vayas aprendiendo cada día.</p>

<p class="ex1" style="color:white;"><b>Vale, pero para eso están las libretas</b></p>

<p class="ex1">Si, pero cuántas veces has querido buscar una palabra que apuntastes la semana pasada
y por no tener la libreta a mano, no has podido buscarla? por no mencionar que las 
libretas no te permiten hacer "Ctrl + f" para buscar una palabra.
Para todos estos problemas nace My Dictionary,podrás acceder a todos tus apuntes
desde cualquier lugar.</p>

</div>


</div>
</div>
<div class="footer-index display-flex justify-content-space-between fullWidth">
	
	<div class="footer-div ">
    <h4 style="text-align: center;">Datos</h4>
    	<ul>
          <li>Manuel Alcántara Baldasquín</li>
          <li>2º DAW</li>
          <li>Málaga</li>
          <li><a href="https://github.com/ManuelAlcantaraBaldasquin">Github</a></li>
        </ul>
    </div>
    
    
    <div class="footer-div">
    <h4 style="text-align: center;">Tecnologías</h4>
        <ul>
          <li>Php</li>
          <li>Java Script</li>
          <li>HTML5</li>
          <li>Css</li>
          <li>Bootstrap</li>
        </ul>
    </div>
    
    <div class="footer-div">
    <h4 style="text-align: center;">Social</h4>
        <ul>
          <li><a href="https://twitter.com/MyDictionary">Twitter</a></li>
          <li><a href="https://Instagram.com/MyDictionary">Instagram</a></li>
          <li><a href="https://Facebook.com/MyDictionary">Facebook</a></li>
          <li><a href="https://reddit.com/MyDictionary">Reddit</a></li>
          <li><a href="https://Github.com/MyDictionary">Github</a></li>
        </ul>
	</div>
	
</div>


</body>
</html>
