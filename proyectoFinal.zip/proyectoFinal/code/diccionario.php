<?php
    include ('actions/dbConfig.php');
    session_start();

		$IDuser = $_SESSION["IDuser"]; //guardamos la id del usuario logueado
  	//Sentencia que toma todos los valores de la tabla diccionario
  	$sql  = "SELECT * FROM `diccionario` WHERE `IDuser` = $IDuser ORDER BY `Idioma`;";
  	$reg = $mysqli->query($sql);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>diccionario</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  
	  <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
	  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
      <link rel="stylesheet" href="../css/style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script type="text/javascript" src="js/scripts.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
	<div class="header" style="padding: 1px 10px;">
	
	<h1>Lista de tus diccionarios</h1>
	<a href="main.php?destroy" class="logout fas fa-sign-out-alt ">Desconectarse</a>
	</div>
	Bienvenido <?= $_SESSION["user"] ?> ¿Qué idioma aprenderas hoy?<br>
	<button id="openCreateDic" data-backdrop="false" style="float: right" type="button" class="btn btn-success" data-toggle="modal" data-target="#createModal">
	<i class="fas fa-plus-square"></i> crear diccionario</button>
	<br>			 
				
	 <div class="col-xs-6 col-md-12">
    <table style="width:100%" class="table" id="tDiccionario">
      <tr>
        <th style="width:12.5%">Nombre</th><th style="width:12.5%">Idioma</th><th style="width:50%">Descripción</th><th style="width:25%" colspan="3">Acciones</th>
      </tr>
      <tr>
       <!-- Bucle por cada registro muestra en la tabla (nombre, descripcion y idioma) -->
        <?php while ($row = mysqli_fetch_assoc($reg)) {?>
        <td class=""> <?php echo $row["nombre"]; ?> </td>
        <td class=""> <?php echo $row["idioma"]; ?> </td>
        <td class=""> <?php echo $row["descripcion"]; ?> </td>
		<td>
				<a data-backdrop="false" onclick="mostrarForm(2)" href="actions/edit.php=<?php echo $row['id']; ?>" class="btn btn-warning" >
				<i class="fas fa-edit"></i> Editar</a>
		</td>
				<td><button id="openDeleteDic" onclick="eliminarDiccionario(<?=$row["IDdiccionario"]?>)" data-backdrop="false" type="submit" class="btn btn-danger" data-toggle="modal"
				data-target="#deleteModal">
				<i class="fas fa-trash-alt"></i> Eliminar</button>
		</td>
		<td>
				<button id="abrirPalabras" onclick="buscarPalabras(<?=$row["IDdiccionario"]?>)" type="button" class="btn btn-primary" data-backdrop="false" data-toggle="modal"
				data-target="#palabrasModal">
				<i class="fas fa-external-link-alt"></i> Abrir</button>
		</td>
				</tr>
      <?php }; ?>
    </table></div>
		 
	
	
<!-- Palabras Modal		   -->
  <div class="modal fade" id="palabrasModal" role="dialog">   
	</div>  
		  
		  
  <!-- Create Modal -->
  <div class="modal fade" id="createModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <form name="create_diccionario" id="create_diccionario" method="POST">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Crear Diccionario</h4>
        </div>
        <div class="modal-body">
          <h3>Introduce los datos</h3>
          <p><input type="text" class="input-width form-control" name="nombre" id="nombre" placeholder="Nombre"></p>
          <div class="row justify-content-center" style="text-align: center;">
          <span class="col-6">Selecciona un idioma:</span>
          <select class="col-6" name="idioma" class=" form-control">
          <?php $sql  = "SELECT * FROM `idioma`";
  	             $reg = $mysqli->query($sql);
          while ($row = mysqli_fetch_assoc($reg)){?>
          <option value="<?=$row['IDidioma'] ?>"><?=$row['idioma'] ?></option>
          <?php }?>
        </select>
        </div><br>
		<p><textarea name="descripcion" class="form-control input-width" rows="5" id="descripcion" placeholder="Descripcion"></textarea></p>
        </div>
        <div class="modal-footer">
        <button name="confirmCreateDicc" onclick="crearDiccionario(<?=$IDuser?>)" type="submit" class="btn btn-success" data-dismiss="modal">Crear</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  
   <!-- Edit Modal -->
  <div class="modal fade" id="editModal" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
      <form name="edit_diccionario" id="edit_diccionario" method="POST">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Editar Diccionario</h4>
        </div>
        <div class="modal-body">
          <h3>Introduce los nuevos datos</h3>
          <?php $sql  = "SELECT * FROM `idioma`";
  	             $reg = $mysqli->query($sql);
          while ($row = mysqli_fetch_assoc($reg)){?>
          <p><input type="text" class="input-width form-control" name="nombre" id="nombre" value="<?=$row['nombre'] ?>"></p>
          <div class="row justify-content-center" style="text-align: center;">
          <span class="col-6">Selecciona un idioma:</span>
          <select class="col-6" name="idioma" class=" form-control">
          <?php $sql  = "SELECT * FROM `idioma`";
  	             $reg = $mysqli->query($sql);
          while ($row = mysqli_fetch_assoc($reg)){?>
          <option value="<?=$row['IDidioma'] ?>"><?=$row['idioma'] ?></option>
          <?php }?>
        </select>
        </div><br>
		<p><textarea name="descripcion" class="form-control input-width" rows="5" id="descripcion" placeholder="Descripcion"></textarea></p>
        <?php }?>
        </div>
        <div class="modal-footer">
        <button name="confirmCreateDicc" onclick="crearDiccionario(<?=$IDuser?>)" type="submit" class="btn btn-success" data-dismiss="modal">Crear</button>
          <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
        </div>
        </form>
      </div>
    </div>
  </div>
  
  <!-- Delete Modal -->
  <div class="modal fade" id="deleteModal" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<form name="delete_diccionario" id="delete_diccionario" method="post">
					<div class="modal-header">						
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title">Eliminar Diccionario</h4>
					</div>
					<div class="modal-body">					
						<p>¿Seguro que quiere eliminar el diccionario?</p>
						<p class="text-warning"><small>Esta acción no se puede deshacer</small></p>
						<input type="hidden" name="delete_id" id="delete_id">
					</div>
					<div class="modal-footer">
          			<button onclick="confirmDeleteDicc()" type="submit" class="btn btn-danger" data-dismiss="modal">Eliminar</button>
          			<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	</body>
</html>
