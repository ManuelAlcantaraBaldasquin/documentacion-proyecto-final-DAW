<?php
    include ('actions/dbConfig.php');
    session_start();

		$IDuser = $_SESSION["IDuser"]; //guardamos la id del usuario logueado
  	//Sentencia que toma todos los valores de la tabla usuarios
  	$sql  = "SELECT * FROM `usuarios` WHERE `admin` = 0;";
  	$reg = $mysqli->query($sql);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>usuarios</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	  <link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
	  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
      <link rel="stylesheet" href="../css/style.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
		<script type="text/javascript" src="js/scripts.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>
	<body>
	<div class="header">
		<a href="main.php?destroy" class=" logout fas fa-sign-out-alt ">Desconectarse</a>
		<p class="logo">Listado completo de usuarios</p>
		<a href="usuarios.php" class="">Ver usuarios</a>
		<a href="diccionarioAdmin.php" class="">Ver diccionarios</a>

  </div>
  <br>
				
	 <div class="col-xs-6 col-md-12" style="margin:auto;">
    <table style="width:60%" class="table" id="tDiccionario">
      <tr>
        <th style="width:10%">IDUser</th><th style="width:25%">User</th><th style="width:45%">Email</th><th style="width:15%">Acciones</th>
      </tr>
      <tr>
       <!-- Bucle por cada registro muestra en la tabla (user, email) -->
        <?php while ($row = mysqli_fetch_assoc($reg)) {?>
        <td class=""> <?php echo $row["IDuser"]; ?> </td>
        <td class=""> <?php echo $row["user"]; ?> </td>
        <td class=""> <?php echo $row["mail"]; ?> </td>
		<td>
				<button name="openDeleteUser" id="openDeleteUser" onclick="eliminarUser(<?=$row["IDuser"]?>)" data-backdrop="false" type="submit" class="btn btn-danger" data-toggle="modal"
				data-target="#deleteUserModal">
				<i class="fas fa-trash-alt"></i> Eliminar</button>
		</td>
		</tr>
      <?php }; ?>
    </table></div>
    
		 
		 
  <!-- Delete Modal -->
  <div class="modal fade" id="deleteUserModal" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<form name="delete_user" id="delete_user" method="post">
					<div class="modal-header">						
						<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						<h4 class="modal-title">Eliminar Usuario</h4>
					</div>
					<div class="modal-body">					
						<p>¿Seguro que quiere eliminar a este Usuario?</p>
						<p class="text-warning"><small>Esta acción no se puede deshacer</small></p>
						<input type="hidden" name="delete_id" id="delete_id">
					</div>
					<div class="modal-footer">
          			<button onclick="confirmDeleteUser()" type="submit" class="btn btn-danger" data-dismiss="modal">Eliminar</button>
          			<button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
					</div>
				</form>
			</div>
		</div>
	</div>

	</body>
</html>