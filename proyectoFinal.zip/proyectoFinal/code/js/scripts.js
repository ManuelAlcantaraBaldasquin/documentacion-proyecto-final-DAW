idSeleccionado = 0;

//Eliminar Diccionario
function eliminarDiccionario(id) {
	idSeleccionado = id;
}

function confirmDeleteDicc() {
	$.post("actions/delete.php",
    	    {
    	      id: idSeleccionado,
    	    },
   function(){
    	    	location.reload();
    	    });
}

function eliminarPalabra(id) {
	idSeleccionado = id;
	
	$.post("actions/eliminarPalabra.php",
    	    {
    	      id: idSeleccionado,
    	    },
	function(){
    	location.reload();	
    });
}

//Crear Diccionario
function crearDiccionario(id) {
	var nombre = $('#create_diccionario').find('input[name="nombre"]').val();
	var idioma = $('#create_diccionario').find('option:selected').text();
	var IDidioma = $('#create_diccionario').find('option:selected').val();
	var descripcion = $('#create_diccionario').find('textarea[name="descripcion"]').val();
	$.post("actions/create.php",
    	    {
			  IDidioma: IDidioma,
			  IDuser: id,
    	      nombre: nombre,
    	      idioma: idioma,
    	      descripcion: descripcion,
    	    },
    	    function(){
    	    	location.reload();	
    	    });
}


//Crear Usuario
function crearUsuario() {
	var nombre = $('#create_user').find('input[name="user"]').val();
	var email = $('#create_user').find('input[name="mail"]').val();
	var password = $('#create_user').find('input[name="password"]').val();
	$.post("actions/createUser.php",
    	    {
			  user: nombre,
			  mail: email,
    	      password: password,
    	    },
    	    function(){
    	    	location.reload();	
    	    });
}
//Eliminar usuario
idUserSeleccionado = 0;

function eliminarUser(id) {
	idUserSeleccionado = id;
	console.log("gato");
}
function confirmDeleteUser() {
	$.post("actions/deleteUser.php",
    	    {
    	      id: idUserSeleccionado,
    	    },
   function(){
    	    	location.reload();	
    	    });
}

function buscarPalabras(id) {
	idUserSeleccionado = id;
	$.post("actions/getPalabras.php",
    	    {
    	      id: idUserSeleccionado,
    	    },
    function(respuesta){
    	    	$("#palabrasModal").empty();
    	    	$("#palabrasModal").append(respuesta);
    	    });
}

function crearPalabras() {
			$.post("actions/getPalabras.php",
    	    {
			otro: 'nueva_palabra',
    	      id: idUserSeleccionado,
    	    },
    	    function(respuesta){
    	    	$("#palabrasModal").find("table").append(respuesta);
    	    });		
};

function guardar_nueva_palabra(){
	var nPalabra = $('#nueva_palabra').find('input.palabra').val();
	var nSignificado = $('#nueva_palabra').find('input.significado').val();
	var nEjemplo = $('#nueva_palabra').find('input.ejemplo').val();
	
	$.post("actions/crearPalabra.php",
	{
		palabra: nPalabra,
		significado: nSignificado,
		ejemplo: nEjemplo,
		id: idUserSeleccionado,
	},
	function(){
		$.post("actions/getPalabras.php",
	    	    {
				otro: 'ultima_palabra',
	    	      id: idUserSeleccionado,
	    	    },
	    	    function(respuesta){
	    	    	$("#nueva_palabra").remove();
	    	    	$("#palabrasModal").find("table").append(respuesta);
	    	    });		
	});
}