<?php
header("location:code/index.php");

 ?>
